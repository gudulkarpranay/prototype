import tkinter as tk

t = tk.Tk()
t.geometry("500x500")
t.title("Demo")
t.mainloop()